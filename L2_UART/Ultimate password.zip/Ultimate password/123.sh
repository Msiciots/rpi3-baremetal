#!/bin/bash

make clean
make 
rm /media/wei_1804/9016-4EF8/kernel8.img
cp kernel8.img /media/wei_1804/9016-4EF8/